package com.employeeTravel.main.service;

public class SlabDetailsService implements SlabDetailsServiceInterface {

}
