package com.employeeTravel.main.service;

public class BookingDetailsService implements BookingDetailsServiceInterface {

}
