package com.employeeTravel.main.service;

public interface BookingDetailsServiceInterface {

}
