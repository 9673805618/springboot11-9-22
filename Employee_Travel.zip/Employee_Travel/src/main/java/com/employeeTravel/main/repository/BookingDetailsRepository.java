package com.employeeTravel.main.repository;

import com.employeeTravel.main.domain.BookingDetails;

public class BookingDetailsRepository implements BookingDetailsRepositoryInterface {

	@Override
	public boolean viewBookingDetailsById(BookingDetails bookingDetails) {
		// TODO Auto-generated method stub
		return false;
	}

}
