package com.employeeTravel.main.domain;

public class SlabDetails {

}
