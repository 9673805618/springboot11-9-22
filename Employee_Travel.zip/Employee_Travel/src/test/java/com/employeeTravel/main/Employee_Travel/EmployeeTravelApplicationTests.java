package com.employeeTravel.main.Employee_Travel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeTravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
