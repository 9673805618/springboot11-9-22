package com.employeeTravel.main.service;

import com.employeeTravel.main.domain.Login;

public interface LoginServiceInterface {
	public Login validationUser(Login login);

}
